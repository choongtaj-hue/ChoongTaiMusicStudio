package com.choongtai.musicstudio;

import java.io.BufferedOutputStream;
import java.io.IOException;
import java.io.OutputStream;

public final class WaveExporter {
    private WaveExporter() {}

    public static void write(OutputStream destination, MusicProject p) throws IOException {
        boolean song = p.songMode;
        long bars = song ? p.arrangement.length : 1L;
        long totalSteps = bars * MusicProject.STEPS * p.loops;
        long frames = SynthEngine.Session.framesFor(p, song, p.loops);
        long dataSize = frames * 2;
        if (dataSize > 0xFFFFFFFFL - 36) throw new IOException("WAV vượt kích thước hỗ trợ");
        try (BufferedOutputStream stream = new BufferedOutputStream(destination, 65536)) {
            stream.write(new byte[]{'R','I','F','F'});
            le32(stream, dataSize + 36);
            stream.write(new byte[]{'W','A','V','E','f','m','t',' '});
            le32(stream, 16);
            le16(stream, 1); // PCM
            le16(stream, 1); // mono
            le32(stream, SynthEngine.SAMPLE_RATE);
            le32(stream, SynthEngine.SAMPLE_RATE * 2L);
            le16(stream, 2); // block align
            le16(stream, 16); // bit depth
            stream.write(new byte[]{'d','a','t','a'});
            le32(stream, dataSize);
            try (SynthEngine.Session synth = new SynthEngine.Session(p, song, totalSteps, null)) {
            short[] samples = new short[2048];
            byte[] pcm = new byte[4096];
            long done = 0;
            while (done < frames) {
                int count = (int) Math.min(samples.length, frames - done);
                synth.render(samples, count);
                for (int i = 0; i < count; i++) {
                    pcm[2 * i] = (byte) (samples[i] & 255);
                    pcm[2 * i + 1] = (byte) ((samples[i] >>> 8) & 255);
                }
                stream.write(pcm, 0, count * 2);
                done += count;
            }
            stream.flush();
            }
        }
    }

    private static void le16(OutputStream out, int n) throws IOException {
        out.write(n & 255); out.write((n >>> 8) & 255);
    }
    private static void le32(OutputStream out, long n) throws IOException {
        out.write((int) n & 255);
        out.write((int) (n >>> 8) & 255);
        out.write((int) (n >>> 16) & 255);
        out.write((int) (n >>> 24) & 255);
    }
}
