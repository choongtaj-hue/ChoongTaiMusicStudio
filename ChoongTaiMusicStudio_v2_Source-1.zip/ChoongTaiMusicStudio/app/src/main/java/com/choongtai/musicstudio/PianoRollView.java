package com.choongtai.musicstudio;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.view.MotionEvent;
import android.view.View;

public final class PianoRollView extends View {
    private final Paint paint = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final MusicProject project;
    private final Runnable onEdit;
    private final int cellW;
    private final int cellH;
    private final int keyW;
    private int playStep = -1;
    private static final String[] NAMES = {"C", "C#", "D", "D#", "E", "F", "F#", "G", "G#", "A", "A#", "B"};

    public PianoRollView(Context context, MusicProject project, Runnable onEdit) {
        super(context);
        this.project = project;
        this.onEdit = onEdit;
        float density = context.getResources().getDisplayMetrics().density;
        cellW = (int) (46 * density + .5f);
        cellH = (int) (32 * density + .5f);
        keyW = (int) (54 * density + .5f);
        setLayerType(View.LAYER_TYPE_SOFTWARE, null);
    }

    @Override protected void onMeasure(int wMeasureSpec, int hMeasureSpec) {
        setMeasuredDimension(keyW + 16 * cellW, 24 * cellH);
    }

    @Override protected void onDraw(Canvas c) {
        c.drawColor(0xFF101829);
        MusicProject.Pattern pattern = project.patterns[project.selectedPattern];
        int melodic = project.selectedMelodicTrack;
        int color = MusicProject.TRACK_COLORS[melodic + 4];
        for (int r = 0; r < MusicProject.PITCHES; r++) {
            int midi = 48 + MusicProject.PITCHES - r - 1;
            String name = NAMES[midi % 12] + (midi / 12 - 1);
            boolean black = name.contains("#");
            paint.setColor(black ? 0xFF151D2C : 0xFF1D2A40);
            c.drawRect(0, r * cellH, keyW - 1, (r + 1) * cellH - 1, paint);
            paint.setColor(black ? 0xFF8D9BAF : Color.WHITE);
            paint.setTextSize(cellH * 0.38f);
            paint.setFakeBoldText(name.startsWith("C") && !black);
            c.drawText(name, 6, r * cellH + cellH * 0.62f, paint);
            paint.setFakeBoldText(false);
            for (int s = 0; s < MusicProject.STEPS; s++) {
                int left = keyW + s * cellW;
                paint.setColor(s % 4 == 0 ? 0xFF1D293C : 0xFF172135);
                if (black) paint.setColor(s % 4 == 0 ? 0xFF192234 : 0xFF121B2C);
                c.drawRect(left + 1, r * cellH + 1, left + cellW - 1, (r + 1) * cellH - 1, paint);
                int velocity = pattern.notes[melodic][r][s];
                if (velocity != 0) {
                    paint.setColor(velocity == 2 ? 0xFFFFD280 : color);
                    c.drawRoundRect(left + 2, r * cellH + 3, left + cellW - 3,
                            (r + 1) * cellH - 3, 6, 6, paint);
                }
            }
        }
        if (playStep >= 0) {
            paint.setColor(0x66FFFFFF);
            int x = keyW + playStep * cellW;
            c.drawRect(x, 0, x + 2, getHeight(), paint);
        }
    }

    @Override public boolean onTouchEvent(MotionEvent event) {
        if (event.getAction() == MotionEvent.ACTION_DOWN) return true;
        if (event.getAction() != MotionEvent.ACTION_UP) return true;
        int step = (int) ((event.getX() - keyW) / cellW);
        int row = (int) (event.getY() / cellH);
        if (event.getX() < keyW || step < 0 || step >= 16 || row < 0 || row >= 24) return true;
        int[][] notes = project.patterns[project.selectedPattern].notes[project.selectedMelodicTrack];
        notes[row][step] = notes[row][step] == 0 ? 2 : 0;
        invalidate();
        if (onEdit != null) onEdit.run();
        performClick();
        return true;
    }

    @Override public boolean performClick() { super.performClick(); return true; }
    public void setPlayStep(int step) { playStep = step; invalidate(); }
}
