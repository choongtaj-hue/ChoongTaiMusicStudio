package com.choongtai.musicstudio;

import java.util.ArrayList;

/** Pure Java procedural synthesizer; no samples, permissions or external dependencies. */
public final class SynthEngine {
    public static final int SAMPLE_RATE = 44100;
    private static final double TAU = 2.0 * Math.PI;
    private SynthEngine() {}

    public interface OnStep { void changed(int step, int pattern, int slot); }

    public static final class Session implements AutoCloseable {
        private final MusicProject project;
        private final boolean songMode;
        private final long maxSteps; // -1 = play forever
        private final OnStep listener;
        private final ArrayList<Voice> voices = new ArrayList<>();
        private final short[][] drumSamples = new short[4][];
        private PcmFile.Reader backing;
        private final double[] delayLine;
        private int delayCursor;
        private double filterState;
        private final double stepFrames;
        private final double stepSeconds;
        private long currentFrame = 0;
        private long nextStep = 0;
        private double nextStepFrame = 0.0;

        public Session(MusicProject project, boolean songMode, long maxSteps, OnStep listener) {
            this.project = project;
            this.songMode = songMode;
            this.maxSteps = maxSteps;
            this.listener = listener;
            int bpm = Math.max(60, Math.min(200, project.bpm));
            this.stepFrames = SAMPLE_RATE * 60.0 / (bpm * 4.0);
            this.stepSeconds = stepFrames / SAMPLE_RATE;
            int delayFrames = Math.max(1,(int)(SAMPLE_RATE*60.0/(bpm*2.0)));
            this.delayLine=new double[delayFrames];
            for(int i=0;i<4;i++) {
                if(project.samplePaths[i]!=null)
                    drumSamples[i]=PcmFile.loadShortSample(project.samplePaths[i],30);
            }
            if(project.audioClipPath!=null) {
                try { backing=new PcmFile.Reader(project.audioClipPath); }
                catch (java.io.IOException ignored) { backing=null; }
            }
        }

        public static long framesFor(MusicProject p, boolean songMode, int loops) {
            long steps = (songMode ? p.arrangement.length : 1L) * MusicProject.STEPS * loops;
            long seqFrames=(long)Math.ceil(steps*SAMPLE_RATE*60.0/(Math.max(60,Math.min(200,p.bpm))*4.0));
            long clipFrames=PcmFile.frames(p.audioClipPath);
            return Math.max(seqFrames,clipFrames)+SAMPLE_RATE; // include audio clip and tails
        }

        /** Produce next block of mono signed 16-bit PCM. */
        public void render(short[] dest, int size) {
            for (int i = 0; i < size; i++) {
                if ((maxSteps < 0 || nextStep < maxSteps) && currentFrame >= (long) Math.ceil(nextStepFrame)) {
                    int step = (int) (nextStep % MusicProject.STEPS);
                    int slot = songMode ? (int) ((nextStep / MusicProject.STEPS) % project.arrangement.length) : -1;
                    int pattern = songMode ? project.arrangement[slot] : project.selectedPattern;
                    if (pattern >= 0 && pattern < MusicProject.PATTERNS) trigger(project.patterns[pattern], step);
                    if (listener != null) listener.changed(step, pattern, slot);
                    nextStep++;
                    nextStepFrame += stepFrames;
                }
                double level = 0;
                for (int n = voices.size() - 1; n >= 0; n--) {
                    Voice v = voices.get(n);
                    level += v.sample();
                    if (v.age >= v.duration) voices.remove(n);
                }
                if(backing!=null) level+=backing.sampleAt(currentFrame)*project.audioClipVolume;
                // Master insert effects: drive, one-pole lowpass, tempo-synced echo.
                level*=1.0+project.masterDrive*0.025;
                level = level/(1.0 + Math.abs(level) * 0.85);
                double alpha = 0.015 + 0.97 * Math.pow(project.masterFilter/100.0, 2);
                filterState += (level - filterState) * alpha;
                level = filterState;
                if(project.masterDelay>0) {
                    double delayed=delayLine[delayCursor];
                    delayLine[delayCursor]=level+delayed*0.25;
                    level+=delayed*(project.masterDelay/100.0);
                    if(++delayCursor==delayLine.length)delayCursor=0;
                }
                dest[i] = (short) (Math.max(-1.0, Math.min(1.0, level)) * 32767.0);
                currentFrame++;
            }
        }

        private void trigger(MusicProject.Pattern pattern, int step) {
            for (int d = 0; d < 4; d++) {
                int velocity = pattern.drums[d][step];
                if (velocity != 0 && !project.mute[d]) {
                    double gain=project.volume[d]*(velocity==2?1.0:0.7);
                    if(drumSamples[d]!=null) voices.add(new Voice(drumSamples[d],gain));
                    else voices.add(new Voice(d,0,gain,stepSeconds));
                }
            }
            for (int tr = 0; tr < 4; tr++) {
                int instrument = tr + 4;
                if (project.mute[instrument]) continue;
                for (int row = 0; row < MusicProject.PITCHES; row++) {
                    int velocity = pattern.notes[tr][row][step];
                    if (velocity != 0) {
                        int midi = 48 + MusicProject.PITCHES - 1 - row;
                        double gain = project.volume[instrument] * (velocity == 2 ? 1 : 0.67);
                        voices.add(new Voice(instrument, midi, gain, stepSeconds, project.instrumentTones[tr]));
                    }
                }
            }
            // Limit density when a user paints many overlapping notes.
            while (voices.size() > 96) voices.remove(0);
        }

        @Override public void close() {
            if(backing!=null)try {backing.close();}catch(java.io.IOException ignored){}
            backing=null;
            voices.clear();
        }
    }

    private static final class Voice {
        final int type;
        int oscillatorTone;
        short[] oneShot;
        int oneShotIndex;
        final double freq;
        final double amplitude;
        final double duration;
        double phase;
        double age;
        double lastNoise;
        int seed;

        Voice(short[] data,double gain) {
            this.type=8;
            this.oneShot=data;
            this.amplitude=gain;
            this.duration=data.length/(double)SAMPLE_RATE;
            this.freq=0;
        }

        Voice(int type, int midi, double gain, double stepSec) {
            this(type,midi,gain,stepSec,0);
        }

        Voice(int type, int midi, double gain, double stepSec,int oscillatorTone) {
            this.oscillatorTone=oscillatorTone;
            this.type = type;
            this.amplitude = gain;
            double noteFreq = 440.0 * Math.pow(2.0, (midi - 69.0) / 12.0);
            this.freq = (type == 4) ? noteFreq * 0.5 : noteFreq;
            switch (type) {
                case 0: duration = 0.40; break;
                case 1: duration = 0.28; break;
                case 2: duration = 0.15; break;
                case 3: duration = 0.26; break;
                case 4: duration = stepSec * 1.65; break;
                case 5: duration = stepSec * 1.35; break;
                case 6: duration = stepSec * 1.45; break;
                default: duration = stepSec * 3.5; break;
            }
            seed = 0x45D9F3B + type * 65537 + midi * 997;
        }

        private double whiteNoise() {
            seed = seed * 1664525 + 1013904223;
            return ((seed >>> 8) / 8388608.0) - 1.0;
        }

        double sample() {
            double t = age;
            double result;
            switch (type) {
                case 8: {
                    result=oneShotIndex<oneShot.length?oneShot[oneShotIndex++]/32768.0:0;
                    break;
                }
                case 0: { // pitch-falling kick
                    phase += TAU * (49.0 + 150.0 * Math.exp(-t * 30.0)) / SAMPLE_RATE;
                    result = (Math.sin(phase) * Math.exp(-t * 11.0)
                            + whiteNoise() * 0.14 * Math.exp(-t * 110.0)) * 0.88;
                    break;
                }
                case 1: { // snare: pitched body + fizz
                    phase += TAU * 175.0 / SAMPLE_RATE;
                    result = (whiteNoise() * 0.70 + Math.sin(phase) * 0.29)
                            * Math.exp(-t * 18.0) * 0.62;
                    break;
                }
                case 2: { // closed hat (high passed noise)
                    double n = whiteNoise();
                    lastNoise = lastNoise * 0.85 + n * 0.15;
                    result = (n - lastNoise) * Math.exp(-t * 45.0) * 0.35;
                    break;
                }
                case 3: { // a clustered snappy clap
                    double n = whiteNoise();
                    lastNoise = lastNoise * 0.8 + n * 0.2;
                    double burst = 0.45 + (Math.cos(t * 2.0 * Math.PI * 32.0) > 0.24 ? 0.55 : 0.0);
                    result = (n - lastNoise) * burst * Math.exp(-t * 16.0) * 0.48;
                    break;
                }
                case 4: { // warm sub bass
                    phase += TAU * freq / SAMPLE_RATE;
                    double env = (1.0 - Math.exp(-t * 180.0)) * Math.min(1.0, (duration - t) * 24.0);
                    result = (Math.sin(phase) * 0.78 + Math.sin(phase * 2) * 0.2)
                            * Math.max(0.0, env) * 0.6;
                    break;
                }
                case 5: { // pluck
                    phase += TAU * freq / SAMPLE_RATE;
                    result = (Math.sin(phase) + 0.32 * Math.sin(phase * 2.0))
                            * Math.exp(-t * 6.0) * 0.34;
                    break;
                }
                case 6: { // organ-style lead
                    phase += TAU * freq / SAMPLE_RATE;
                    result = (Math.sin(phase) * 0.62 + Math.sin(phase * 2) * 0.23
                            + Math.sin(phase * 3) * 0.1)
                            * Math.min(1.0, Math.max(0, (duration - t) * 24.0)) * 0.42;
                    break;
                }
                default: { // soft pad
                    phase += TAU * freq / SAMPLE_RATE;
                    double attack = Math.min(1.0, t * 12.0);
                    double release = Math.min(1.0, Math.max(0.0, (duration - t) * 5.0));
                    result = (Math.sin(phase) * 0.57 + Math.sin(phase * 0.996) * 0.43)
                            * attack * release * 0.26;
                    break;
                }
            }
            if(type>=4 && type<=7 && oscillatorTone!=0) {
                double wrapped=phase%TAU;
                double alt=oscillatorTone==1?Math.sin(wrapped):
                        oscillatorTone==2?(wrapped/Math.PI-1.0):
                        (wrapped<Math.PI?0.7:-0.7);
                double attack=Math.min(1.0,t*80.0);
                double release=Math.min(1.0,Math.max(0.0,(duration-t)*22.0));
                result=result*0.4+alt*0.28*attack*release;
            }
            age += 1.0 / SAMPLE_RATE;
            return result * amplitude;
        }
    }
}
