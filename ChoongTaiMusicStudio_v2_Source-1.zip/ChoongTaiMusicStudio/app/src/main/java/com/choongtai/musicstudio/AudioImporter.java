package com.choongtai.musicstudio;

import android.content.Context;
import android.media.AudioFormat;
import android.media.MediaCodec;
import android.media.MediaExtractor;
import android.media.MediaFormat;
import android.net.Uri;

import java.io.File;
import java.io.IOException;
import java.io.InputStream;
import java.io.BufferedInputStream;
import java.io.EOFException;
import java.nio.ByteBuffer;
import java.nio.ByteOrder;

/** Decode a user-selected audio document into app-owned PCM, streaming without holding full tracks in RAM. */
public final class AudioImporter {
    private AudioImporter() {}
    public static void importToWav(Context context, Uri uri, File out, int maxSeconds) throws IOException {
        // MediaCodec decoder is unreliable for uncompressed WAV on some devices.
        // Implement PCM16 RIFF/WAV directly; use Android's decoder for compressed files.
        try(InputStream raw=context.getContentResolver().openInputStream(uri)) {
            if(raw==null)throw new IOException("Không mở được tệp nhập");
            BufferedInputStream probe=new BufferedInputStream(raw);
            probe.mark(12);
            byte[] signature=new byte[12];
            int count=probe.read(signature);probe.reset();
            if(count==12 && signature[0]=='R' && signature[1]=='I' && signature[2]=='F'
                    && signature[3]=='F' && signature[8]=='W' && signature[9]=='A'
                    && signature[10]=='V' && signature[11]=='E') {
                try { importPcmWave(probe,out,maxSeconds); }
                catch(IOException | RuntimeException ex) {if(out.exists())out.delete();throw ex;}
                return;
            }
        }
        MediaExtractor extractor = new MediaExtractor();
        MediaCodec codec = null;
        boolean finished = false;
        try {
            extractor.setDataSource(context,uri,null);
            MediaFormat input = null;
            for(int i=0;i<extractor.getTrackCount();i++) {
                MediaFormat candidate=extractor.getTrackFormat(i);
                String mime=candidate.getString(MediaFormat.KEY_MIME);
                if(mime!=null && mime.startsWith("audio/")) {extractor.selectTrack(i); input=candidate;break;}
            }
            if(input==null) throw new IOException("Tệp không có kênh âm thanh");
            String mime=input.getString(MediaFormat.KEY_MIME);
            codec=MediaCodec.createDecoderByType(mime);
            codec.configure(input,null,null,0);
            codec.start();
            boolean inputDone=false, outputDone=false;
            int sourceRate=input.getInteger(MediaFormat.KEY_SAMPLE_RATE);
            int channels=input.getInteger(MediaFormat.KEY_CHANNEL_COUNT);
            if(sourceRate<8000 || sourceRate>192000 || channels<1 || channels>8)
                throw new IOException("Tốc độ mẫu hoặc số kênh chưa được hỗ trợ");
            long sourceFrames=0, outputFrames=0;
            short[] converted=new short[8192]; int outPos=0;
            MediaCodec.BufferInfo info=new MediaCodec.BufferInfo();
            long idleSince=System.currentTimeMillis();
            try(PcmFile.Writer writer=new PcmFile.Writer(out)) {
                while(!outputDone) {
                    if(!inputDone) {
                        int slot=codec.dequeueInputBuffer(10000);
                        if(slot>=0) {
                            ByteBuffer buffer=codec.getInputBuffer(slot);
                            if(buffer==null) throw new IOException("Decoder không cấp input buffer");
                            buffer.clear();
                            int len=extractor.readSampleData(buffer,0);
                            if(len<0) { codec.queueInputBuffer(slot,0,0,0,MediaCodec.BUFFER_FLAG_END_OF_STREAM);inputDone=true; }
                            else { codec.queueInputBuffer(slot,0,len,extractor.getSampleTime(),0); extractor.advance(); }
                        }
                    }
                    int status=codec.dequeueOutputBuffer(info,10000);
                    if(status==MediaCodec.INFO_OUTPUT_FORMAT_CHANGED) {
                        MediaFormat format=codec.getOutputFormat();
                        sourceRate=format.getInteger(MediaFormat.KEY_SAMPLE_RATE);
                        channels=format.getInteger(MediaFormat.KEY_CHANNEL_COUNT);
                        int encoding=format.containsKey(MediaFormat.KEY_PCM_ENCODING)
                                ? format.getInteger(MediaFormat.KEY_PCM_ENCODING) : AudioFormat.ENCODING_PCM_16BIT;
                        if(encoding!=AudioFormat.ENCODING_PCM_16BIT)
                            throw new IOException("Decoder trả về PCM không phải 16-bit");
                    } else if(status>=0) {
                        if(info.size>0) {
                            ByteBuffer decoded=codec.getOutputBuffer(status);
                            if(decoded==null) throw new IOException("Decoder không cấp output buffer");
                            decoded.position(info.offset);decoded.limit(info.offset+info.size);
                            decoded.order(ByteOrder.LITTLE_ENDIAN);
                            int count=info.size/(channels*2);
                            for(int f=0; f<count;f++) {
                                int sum=0;
                                for(int c=0;c<channels;c++) sum+=decoded.getShort();
                                short sample=(short)(sum/channels);
                                sourceFrames++;
                                long destinationFrames=sourceFrames*PcmFile.SAMPLE_RATE/sourceRate;
                                // Nearest-sample streaming conversion to canonical 44.1 kHz.
                                while(outputFrames<destinationFrames) {
                                    converted[outPos++]=sample;outputFrames++;
                                    if(outputFrames>maxSeconds*(long)PcmFile.SAMPLE_RATE)
                                        throw new IOException("Tệp vượt giới hạn " + maxSeconds + " giây");
                                    if(outPos==converted.length) {writer.write(converted,outPos);outPos=0;}
                                }
                            }
                        }
                        codec.releaseOutputBuffer(status,false);
                        idleSince=System.currentTimeMillis();
                        if((info.flags & MediaCodec.BUFFER_FLAG_END_OF_STREAM)!=0) outputDone=true;
                    } else if(System.currentTimeMillis()-idleSince>25000) {
                        throw new IOException("Bộ giải mã phản hồi quá chậm");
                    }
                }
                if(outPos>0)writer.write(converted,outPos);
                if(writer.frames()==0)throw new IOException("Không có âm thanh hợp lệ");
            }
            finished=true;
        } catch(RuntimeException e) {
            throw new IOException("Không thể giải mã file âm thanh: " + e.getMessage(),e);
        } finally {
            if(codec!=null) {try {codec.stop();} catch(Exception ignored){}codec.release();}
            extractor.release();
            if(!finished && out.exists())out.delete();
        }
    }

    private static void skipFully(InputStream stream,long bytes) throws IOException {
        while(bytes>0){
            long skipped=stream.skip(bytes);
            if(skipped>0)bytes-=skipped;
            else if(stream.read()<0)throw new EOFException("Tệp âm thanh chưa đầy đủ");
            else bytes--;
        }
    }
    private static int get16(byte[] b,int index) {
        return (b[index]&255)|((b[index+1]&255)<<8);
    }
    private static long get32(byte[] b,int index) {
        return (b[index]&255L)|((b[index+1]&255L)<<8)|((b[index+2]&255L)<<16)|((b[index+3]&255L)<<24);
    }
    private static void importPcmWave(InputStream input,File output,int maxSeconds) throws IOException {
        byte[] chunk=new byte[8];byte[] fmt=null;
        skipFully(input,12);
        long dataBytes=0;
        while(true) {
            int offset=0;
            while(offset<8){int n=input.read(chunk,offset,8-offset);if(n<0)throw new EOFException("WAV thiếu chunk data");offset+=n;}
            long size=get32(chunk,4);
            String tag=new String(chunk,0,4,java.nio.charset.StandardCharsets.US_ASCII);
            if("fmt ".equals(tag)) {
                if(size<16 || size>128)throw new IOException("WAV fmt không hỗ trợ");
                fmt=new byte[(int)size];
                int position=0;
                while(position<fmt.length){int n=input.read(fmt,position,fmt.length-position);if(n<0)throw new EOFException();position+=n;}
            } else if("data".equals(tag)) {dataBytes=size;break;}
            else {skipFully(input,size);}
            if((size&1L)!=0)skipFully(input,1);
        }
        if(fmt==null)throw new IOException("WAV không có thông số PCM");
        int audioFormat=get16(fmt,0),channels=get16(fmt,2),sampleRate=(int)get32(fmt,4),bits=get16(fmt,14);
        if(audioFormat!=1 || bits!=16 || channels<1 || channels>8 || sampleRate<8000 || sampleRate>192000)
            throw new IOException("Chỉ hỗ trợ WAV PCM 16-bit, 1–8 kênh, 8–192 kHz");
        if(dataBytes>(long)maxSeconds*sampleRate*channels*2)
            throw new IOException("Tệp WAV vượt giới hạn "+maxSeconds+" giây");
        long readFrames=0,produced=0,frames=dataBytes/(2L*channels);
        short[] block=new short[8192];int length=0;
        byte[] frame=new byte[channels*2];
        try(PcmFile.Writer writer=new PcmFile.Writer(output)) {
            while(readFrames<frames) {
                int read=0;
                while(read<frame.length) {
                    int n=input.read(frame,read,frame.length-read);
                    if(n<0)throw new EOFException("WAV kết thúc bất ngờ");read+=n;
                }
                int total=0;
                for(int c=0;c<channels;c++) total+=(short)get16(frame,c*2);
                short sample=(short)(total/channels);
                readFrames++;
                long destination=readFrames*PcmFile.SAMPLE_RATE/sampleRate;
                while(produced<destination) {
                    block[length++]=sample;produced++;
                    if(length==block.length){writer.write(block,length);length=0;}
                }
            }
            if(length>0)writer.write(block,length);
            if(writer.frames()==0)throw new IOException("WAV rỗng");
        }
    }
}
