package com.choongtai.musicstudio;

import android.media.AudioFormat;
import android.media.AudioManager;
import android.media.AudioTrack;
import android.os.Process;

public final class AudioRunner {
    private volatile boolean running;
    private Thread thread;
    private volatile int generation = 0;
    private AudioTrack audioTrack;

    public synchronized void start(MusicProject project, SynthEngine.OnStep callback) {
        stop();
        running = true;
        final int thisGeneration = ++generation;
        final boolean songMode = project.songMode;
        thread = new Thread(() -> {
            AudioTrack track = null;
            try {
                Process.setThreadPriority(Process.THREAD_PRIORITY_AUDIO);
                int minimum = AudioTrack.getMinBufferSize(SynthEngine.SAMPLE_RATE,
                        AudioFormat.CHANNEL_OUT_MONO, AudioFormat.ENCODING_PCM_16BIT);
                if (minimum <= 0) return;
                track = new AudioTrack(AudioManager.STREAM_MUSIC, SynthEngine.SAMPLE_RATE,
                        AudioFormat.CHANNEL_OUT_MONO, AudioFormat.ENCODING_PCM_16BIT,
                        Math.max(minimum, 4096), AudioTrack.MODE_STREAM);
                synchronized (AudioRunner.this) { audioTrack = track; }
                if (track.getState() != AudioTrack.STATE_INITIALIZED) return;
                try (SynthEngine.Session session = new SynthEngine.Session(project, songMode, -1, callback)) {
                short[] samples = new short[1024];
                track.play();
                while (running && thisGeneration == generation) {
                    session.render(samples, samples.length);
                    int offset = 0;
                    while (offset < samples.length && running && thisGeneration == generation) {
                        int written = track.write(samples, offset, samples.length - offset);
                        if (written <= 0) { if (thisGeneration == generation) running = false; break; }
                        offset += written;
                    }
                }
                }
            } catch (Exception ignored) {
                if (thisGeneration == generation) running = false;
            } finally {
                if (track != null) {
                    try { track.pause(); } catch (Exception ignored) {}
                    try { track.flush(); } catch (Exception ignored) {}
                    track.release();
                }
                synchronized (AudioRunner.this) { if (audioTrack == track) audioTrack = null; }
            }
        }, "beat-studio-audio");
        thread.start();
    }

    public synchronized void stop() {
        generation++;
        running = false;
        AudioTrack track = audioTrack;
        if (track != null) {
            try { track.pause(); track.flush(); } catch (Exception ignored) {}
        }
        Thread old = thread;
        thread = null;
        if (old != null && old.isAlive()) {
            try { old.join(250); } catch (InterruptedException e) { Thread.currentThread().interrupt(); }
        }
    }

    public boolean isRunning() { return running; }
}
