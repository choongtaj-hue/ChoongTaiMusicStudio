package com.choongtai.musicstudio;

import com.naman14.androidlame.AndroidLame;
import com.naman14.androidlame.LameBuilder;
import java.io.BufferedOutputStream;
import java.io.IOException;
import java.io.OutputStream;

/** GPL-3.0-or-later dependency: TAndroidLame 1.1 (JitPack). */
public final class Mp3Exporter {
    private Mp3Exporter() {}
    public static void write(OutputStream destination, MusicProject project) throws IOException {
        final long steps=(project.songMode?project.arrangement.length:1L)*MusicProject.STEPS*project.loops;
        final long frames=SynthEngine.Session.framesFor(project,project.songMode,project.loops);
        AndroidLame lame=null;
        try(BufferedOutputStream out=new BufferedOutputStream(destination,65536);
            SynthEngine.Session session=new SynthEngine.Session(project,project.songMode,steps,null)) {
            lame=new LameBuilder().setInSampleRate(SynthEngine.SAMPLE_RATE)
                    .setOutChannels(1).setOutBitrate(192).setOutSampleRate(SynthEngine.SAMPLE_RATE)
                    .setQuality(4).build();
            short[] pcm=new short[4096];
            byte[] mp3=new byte[16384];
            long pos=0;
            while(pos<frames) {
                int count=(int)Math.min(pcm.length,frames-pos);
                session.render(pcm,count);
                int length=lame.encode(pcm,pcm,count,mp3);
                if(length<0)throw new IOException("LAME encoder trả về mã lỗi: " + length);
                if(length>0)out.write(mp3,0,length);
                pos+=count;
            }
            int remaining=lame.flush(mp3);
            if(remaining<0)throw new IOException("LAME flush lỗi: " + remaining);
            if(remaining>0)out.write(mp3,0,remaining);
            out.flush();
        } catch(UnsatisfiedLinkError | ExceptionInInitializerError e) {
            throw new IOException("Thư viện MP3 không tương thích CPU/Android trên thiết bị này",e);
        } finally { if(lame!=null)lame.close(); }
    }
}
