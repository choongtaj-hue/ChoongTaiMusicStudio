package com.choongtai.musicstudio;

import android.app.Activity;
import android.Manifest;
import android.content.pm.PackageManager;
import android.database.Cursor;
import android.provider.OpenableColumns;
import java.io.File;
import android.app.AlertDialog;
import android.content.Intent;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.net.Uri;
import android.os.Bundle;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.widget.HorizontalScrollView;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.SeekBar;
import android.widget.TextView;
import android.widget.Toast;

import java.io.OutputStream;

public final class MainActivity extends Activity {
    private static final int BG = 0xFF0B1020;
    private static final int PANEL = 0xFF172235;
    private static final int DIM = 0xFF94A3B8;
    private static final int ORANGE = 0xFFFF9F43;
    private static final int AQUA = 0xFF34D399;
    private static final int EXPORT_REQUEST = 1001;
    private static final int EXPORT_MP3_REQUEST = 1002;
    private static final int IMPORT_SAMPLE_REQUEST = 2000;
    private static final int IMPORT_AUDIO_REQUEST = 2004;
    private static final int MIC_PERMISSION = 3001;
    private static final String[] BANKS = {"A", "B", "C", "D"};
    private MusicProject project;
    private final AudioRunner player = new AudioRunner();
    private final MicRecorder microphone = new MicRecorder();
    private File recordingFile;
    private ScrollView page;
    private LinearLayout content;
    private TextView transportButton, currentPosition;
    private TextView[][] drumButtons;
    private PianoRollView pianoRoll;
    private int highlightedStep = -1;
    private volatile boolean exporting = false;

    @Override public void onCreate(Bundle state) {
        super.onCreate(state);
        getWindow().setStatusBarColor(BG);
        getWindow().setNavigationBarColor(BG);
        project = ProjectStore.load(this);
        buildUI();
    }

    private int dp(float v) { return (int) (v * getResources().getDisplayMetrics().density + .5f); }

    private GradientDrawable surface(int color, float radius) {
        GradientDrawable g = new GradientDrawable();
        g.setColor(color);
        g.setCornerRadius(dp(radius));
        return g;
    }

    private TextView text(String label, float size, int color, boolean bold) {
        TextView t = new TextView(this);
        t.setText(label);
        t.setTextColor(color);
        t.setTextSize(size);
        if (bold) t.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        t.setGravity(Gravity.CENTER_VERTICAL);
        return t;
    }

    private TextView action(String label, int color, int labelColor) {
        TextView t = text(label, 13, labelColor, true);
        t.setBackground(surface(color, 11));
        t.setGravity(Gravity.CENTER);
        t.setPadding(dp(11), dp(12), dp(11), dp(12));
        t.setClickable(true);
        return t;
    }

    private LinearLayout column() {
        LinearLayout box = new LinearLayout(this);
        box.setOrientation(LinearLayout.VERTICAL);
        return box;
    }

    private LinearLayout row() {
        LinearLayout box = new LinearLayout(this);
        box.setOrientation(LinearLayout.HORIZONTAL);
        box.setGravity(Gravity.CENTER_VERTICAL);
        return box;
    }

    private void addGap(LinearLayout to, int height) {
        View space = new View(this);
        to.addView(space, new LinearLayout.LayoutParams(1, dp(height)));
    }

    private void addRowGap(LinearLayout to, int width) {
        View space = new View(this);
        to.addView(space, new LinearLayout.LayoutParams(dp(width), 1));
    }

    private void section(String title, String subtitle) {
        addGap(content, 23);
        content.addView(text(title, 17, Color.WHITE, true));
        if (subtitle != null) {
            addGap(content, 4);
            content.addView(text(subtitle, 12, DIM, false));
        }
        addGap(content, 10);
    }

    private void save() { ProjectStore.save(this, project); }

    private void buildUI() {
        int offset = page == null ? 0 : page.getScrollY();
        page = new ScrollView(this);
        page.setFillViewport(true);
        page.setBackgroundColor(BG);
        page.setVerticalScrollBarEnabled(false);
        content = column();
        content.setPadding(dp(14), dp(20), dp(14), dp(40));
        page.addView(content);
        setContentView(page);
        drumButtons = new TextView[4][16];

        TextView pre = text("CHOONG TAI  /  MUSIC PRODUCTION", 11, AQUA, true);
        pre.setLetterSpacing(0.11f);
        content.addView(pre);
        addGap(content, 5);
        content.addView(text("Music Studio", 30, Color.WHITE, true));
        addGap(content, 4);
        content.addView(text("Mobile DAW  •  Offline Beat Maker", 13, DIM, false));
        addGap(content, 20);

        LinearLayout transport = row();
        transportButton = action(player.isRunning() ? "▶ ĐANG PHÁT" : "▶ PHÁT", AQUA, BG);
        transportButton.setOnClickListener(v -> {
            if (player.isRunning()) stopPlayback(); else startPlayback();
        });
        transport.addView(transportButton, new LinearLayout.LayoutParams(0, dp(48), 1.6f));
        addRowGap(transport, 8);
        TextView stop = action("■ DỪNG", PANEL, Color.WHITE);
        stop.setOnClickListener(v -> stopPlayback());
        transport.addView(stop, new LinearLayout.LayoutParams(0, dp(48), 1.0f));
        addRowGap(transport, 8);
        TextView mode = action(project.songMode ? "SONG" : "PATTERN", ORANGE, BG);
        mode.setOnClickListener(v -> {
            boolean wasPlaying = player.isRunning();
            stopPlayback();
            project.songMode = !project.songMode;
            save();
            buildUI();
            if (wasPlaying) startPlayback();
        });
        transport.addView(mode, new LinearLayout.LayoutParams(0, dp(48), 1.2f));
        content.addView(transport);
        addGap(content, 11);
        currentPosition = text("● READY  /  44.1kHz PCM", 12, AQUA, true);
        content.addView(currentPosition);
        addGap(content, 17);
        buildTempo();

        section("01  PATTERN BANK", "Chọn mẫu A–D để sửa nốt và nhịp trống");
        LinearLayout patterns = row();
        for (int b = 0; b < 4; b++) {
            final int target = b;
            TextView btn = action("PAT " + BANKS[b], b == project.selectedPattern ? ORANGE : PANEL,
                    b == project.selectedPattern ? BG : Color.WHITE);
            btn.setOnClickListener(v -> {
                project.selectedPattern = target;
                highlightedStep = -1;
                save();
                buildUI();
            });
            patterns.addView(btn, new LinearLayout.LayoutParams(0, dp(44), 1));
            if (b < 3) addRowGap(patterns, 6);
        }
        content.addView(patterns);

        section("02  SONG ARRANGER", "Chạm mỗi ô để chuyển A → B → C → D → tắt");
        HorizontalScrollView songScroll = new HorizontalScrollView(this);
        songScroll.setHorizontalScrollBarEnabled(false);
        LinearLayout songRow = row();
        for (int i = 0; i < project.arrangement.length; i++) {
            final int index = i;
            int assigned = project.arrangement[i];
            TextView block = action((i + 1) + "\n" + (assigned < 0 ? "–" : BANKS[assigned]),
                    assigned < 0 ? PANEL : MusicProject.TRACK_COLORS[assigned + 4],
                    assigned < 0 ? Color.WHITE : BG);
            block.setOnClickListener(v -> {
                project.arrangement[index] = project.arrangement[index] == 3 ? -1 : project.arrangement[index] + 1;
                save();
                buildUI();
            });
            block.setOnLongClickListener(v -> {
                project.arrangement[index] = -1;
                save(); buildUI(); return true;
            });
            songRow.addView(block, new LinearLayout.LayoutParams(dp(63), dp(59)));
            addRowGap(songRow, 6);
        }
        songScroll.addView(songRow);
        content.addView(songScroll);

        section("03  DRUM SEQUENCER", "Chạm: bật/tắt  •  Giữ: nhấn mạnh  •  16 bước/ô nhịp");
        buildDrumGrid();

        section("04  PIANO ROLL", "Chọn nhạc cụ rồi chạm vào ô để đặt hoặc xóa nốt");
        buildPianoSection();

        section("05  MIXER", "Kéo thanh âm lượng, MUTE để tắt từng nhạc cụ");
        buildMixer();

        section("06  SAMPLE LIBRARY", "Nhập WAV / MP3 / M4A từ điện thoại thay tiếng trống mặc định (tối đa 30 giây/file)");
        buildSampleSection();
        section("07  AUDIO / THU GIỌNG HÁT", "Micro hoặc nhập nhạc nền; phát và trộn từ đầu bài");
        buildAudioSection();
        section("08  MASTER EFFECTS", "Drive  •  Low-pass filter  •  Echo đồng bộ BPM");
        buildEffectsSection();
        section("09  PROJECT / EXPORT", "Xuất WAV PCM hoặc MP3 192 kbps offline");
        buildProjectSection();
        addGap(content, 16);
        content.addView(text("Phiên bản 2.0  •  Sample, Micro, FX, MP3  •  VST3 máy tính chưa hỗ trợ", 11, DIM, false));
        page.post(() -> page.scrollTo(0, offset));
    }

    private void buildTempo() {
        LinearLayout line = row();
        TextView title = text("TEMPO", 15, Color.WHITE, true);
        line.addView(title);
        addRowGap(line, 15);
        TextView bpm = text(project.bpm + " BPM", 17, ORANGE, true);
        line.addView(bpm);
        content.addView(line);
        SeekBar tempo = new SeekBar(this);
        tempo.setMax(140);
        tempo.setProgress(project.bpm - 60);
        tempo.setProgressTintList(android.content.res.ColorStateList.valueOf(ORANGE));
        tempo.setThumbTintList(android.content.res.ColorStateList.valueOf(ORANGE));
        tempo.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            @Override public void onProgressChanged(SeekBar sb, int progress, boolean fromUser) {
                if (fromUser) { project.bpm = progress + 60; bpm.setText(project.bpm + " BPM"); }
            }
            @Override public void onStartTrackingTouch(SeekBar sb) {}
            @Override public void onStopTrackingTouch(SeekBar sb) {
                save();
                if (player.isRunning()) startPlayback(); // audio session captures tempo at start
            }
        });
        content.addView(tempo);
    }

    private void buildDrumGrid() {
        HorizontalScrollView horizontal = new HorizontalScrollView(this);
        horizontal.setHorizontalScrollBarEnabled(true);
        LinearLayout table = column();
        LinearLayout heading = row();
        TextView label = text("TRACK", 11, DIM, true);
        heading.addView(label, new LinearLayout.LayoutParams(dp(82), dp(28)));
        for (int s = 0; s < 16; s++) {
            TextView step = text(String.format(java.util.Locale.US, "%02d", s + 1), 11, DIM, true);
            step.setGravity(Gravity.CENTER);
            heading.addView(step, new LinearLayout.LayoutParams(dp(42), dp(28)));
        }
        table.addView(heading);
        for (int d = 0; d < 4; d++) {
            final int track = d;
            LinearLayout gridRow = row();
            TextView name = text(MusicProject.TRACK_NAMES[d], 12, MusicProject.TRACK_COLORS[d], true);
            gridRow.addView(name, new LinearLayout.LayoutParams(dp(82), dp(45)));
            for (int s = 0; s < 16; s++) {
                final int step = s;
                TextView cell = text("", 12, Color.WHITE, true);
                cell.setGravity(Gravity.CENTER);
                drumButtons[d][s] = cell;
                renderCell(d, s);
                cell.setOnClickListener(v -> {
                    int[] hits = project.patterns[project.selectedPattern].drums[track];
                    hits[step] = hits[step] == 0 ? 2 : 0;
                    renderCell(track, step);
                    save();
                });
                cell.setOnLongClickListener(v -> {
                    int[] hits = project.patterns[project.selectedPattern].drums[track];
                    hits[step] = hits[step] == 1 ? 2 : 1;
                    renderCell(track, step);
                    save();
                    return true;
                });
                LinearLayout.LayoutParams cp = new LinearLayout.LayoutParams(dp(38), dp(35));
                cp.setMargins(dp(2), dp(4), dp(2), dp(4));
                gridRow.addView(cell, cp);
            }
            table.addView(gridRow);
        }
        horizontal.addView(table);
        content.addView(horizontal);
        content.addView(text("← Vuốt ngang để xem đủ 16 bước →", 11, DIM, false));
    }

    private void renderCell(int track, int step) {
        TextView cell = drumButtons[track][step];
        if (cell == null) return;
        int state = project.patterns[project.selectedPattern].drums[track][step];
        int color;
        if (state == 2) color = MusicProject.TRACK_COLORS[track];
        else if (state == 1) color = 0xFF51687A;
        else color = (step % 4 == 0) ? 0xFF27384B : PANEL;
        GradientDrawable bg = surface(color, 7);
        if (step == highlightedStep) bg.setStroke(dp(2), 0xFFFFFFFF);
        cell.setBackground(bg);
    }

    private void buildPianoSection() {
        LinearLayout chips = row();
        for (int track = 0; track < 4; track++) {
            final int tr = track;
            int color = MusicProject.TRACK_COLORS[4 + track];
            TextView button = action(MusicProject.TRACK_NAMES[track + 4],
                    track == project.selectedMelodicTrack ? color : PANEL,
                    track == project.selectedMelodicTrack ? BG : Color.WHITE);
            button.setOnClickListener(v -> {
                project.selectedMelodicTrack = tr;
                save(); buildUI();
            });
            chips.addView(button, new LinearLayout.LayoutParams(0, dp(40), 1));
            if (track < 3) addRowGap(chips, 5);
        }
        content.addView(chips);
        addGap(content,8);
        int melody=project.selectedMelodicTrack;
        TextView tone=action("OSCILLATOR: "+MusicProject.TONE_NAMES[project.instrumentTones[melody]]+
                "   (chạm đổi âm sắc)",PANEL,AQUA);
        tone.setOnClickListener(v->{int tr=project.selectedMelodicTrack;
            project.instrumentTones[tr]=(project.instrumentTones[tr]+1)%MusicProject.TONE_NAMES.length;
            tone.setText("OSCILLATOR: "+MusicProject.TONE_NAMES[project.instrumentTones[tr]]+
                    "   (chạm đổi âm sắc)");save();});
        content.addView(tone,new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT,dp(45)));
        addGap(content,10);
        HorizontalScrollView horizontal = new HorizontalScrollView(this);
        ScrollView vertical = new ScrollView(this);
        vertical.setBackground(surface(PANEL, 8));
        vertical.setVerticalScrollBarEnabled(true);
        vertical.setNestedScrollingEnabled(true);
        pianoRoll = new PianoRollView(this, project, this::save);
        vertical.addView(pianoRoll);
        horizontal.addView(vertical, new ViewGroup.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, dp(360)));
        content.addView(horizontal);
        addGap(content, 6);
        content.addView(text("C3 – B4  •  Vuốt dọc/ngang  •  Đoạn hiện tại: "
                + BANKS[project.selectedPattern], 11, DIM, false));
    }

    private void buildMixer() {
        for (int i = 0; i < 8; i++) {
            final int track = i;
            LinearLayout mixer = row();
            TextView name = text(MusicProject.TRACK_NAMES[i], 11, MusicProject.TRACK_COLORS[i], true);
            mixer.addView(name, new LinearLayout.LayoutParams(dp(76), dp(43)));
            SeekBar volume = new SeekBar(this);
            volume.setMax(100);
            volume.setProgress(Math.round(project.volume[i] * 100));
            volume.setProgressTintList(android.content.res.ColorStateList.valueOf(MusicProject.TRACK_COLORS[i]));
            volume.setThumbTintList(android.content.res.ColorStateList.valueOf(MusicProject.TRACK_COLORS[i]));
            volume.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
                @Override public void onProgressChanged(SeekBar sb, int value, boolean fromUser) {
                    if (fromUser) project.volume[track] = value / 100f;
                }
                @Override public void onStartTrackingTouch(SeekBar sb) {}
                @Override public void onStopTrackingTouch(SeekBar sb) { save(); }
            });
            mixer.addView(volume, new LinearLayout.LayoutParams(0, dp(43), 1));
            TextView mute = action(project.mute[i] ? "ON" : "MUTE",
                    project.mute[i] ? 0xFFE86E74 : PANEL, Color.WHITE);
            mute.setOnClickListener(v -> {
                project.mute[track] = !project.mute[track];
                mute.setText(project.mute[track] ? "ON" : "MUTE");
                mute.setBackground(surface(project.mute[track] ? 0xFFE86E74 : PANEL, 11));
                save();
            });
            mixer.addView(mute, new LinearLayout.LayoutParams(dp(68), dp(39)));
            content.addView(mixer);
        }
    }

    private void buildSampleSection() {
        for (int i=0;i<4;i++) {
            final int pad=i;
            LinearLayout line=row();
            TextView label=text(MusicProject.TRACK_NAMES[i]+"\n"+
                    (project.sampleNames[i]!=null?project.sampleNames[i]:"Synth mặc định"),11,
                    MusicProject.TRACK_COLORS[i],true);
            label.setMaxLines(2);
            line.addView(label,new LinearLayout.LayoutParams(0,dp(57),1));
            TextView importButton=action("NHẬP",AQUA,BG);
            importButton.setOnClickListener(v->startAudioPicker(IMPORT_SAMPLE_REQUEST+pad));
            line.addView(importButton,new LinearLayout.LayoutParams(dp(74),dp(43)));
            addRowGap(line,5);
            TextView clear=action("XÓA",PANEL,Color.WHITE);
            clear.setOnClickListener(v->{stopPlayback();project.samplePaths[pad]=null;
                project.sampleNames[pad]=null;save();buildUI();});
            line.addView(clear,new LinearLayout.LayoutParams(dp(64),dp(43)));
            content.addView(line);
            addGap(content,6);
        }
        content.addView(text("Sample được chép vào bộ nhớ riêng, vẫn dùng được khi xóa tệp gốc.",11,DIM,false));
    }

    private void buildAudioSection() {
        content.addView(text("CLIP: "+(project.audioClipName==null?"Chưa có":"♪ "+project.audioClipName),
                12,Color.WHITE,true));
        addGap(content,9);
        LinearLayout line=row();
        TextView record=action(microphone.isRecording()?"■ DỪNG GHI":"● THU MICRO",
                microphone.isRecording()?0xFFE86E74:ORANGE,BG);
        record.setOnClickListener(v->{if(microphone.isRecording()){
                microphone.stop();record.setText("ĐANG LƯU...");
            } else requestMicrophone();});
        line.addView(record,new LinearLayout.LayoutParams(0,dp(49),1.25f));
        addRowGap(line,6);
        TextView importButton=action("NHẬP AUDIO",PANEL,Color.WHITE);
        importButton.setOnClickListener(v->startAudioPicker(IMPORT_AUDIO_REQUEST));
        line.addView(importButton,new LinearLayout.LayoutParams(0,dp(49),1));
        addRowGap(line,6);
        TextView clear=action("XÓA",PANEL,Color.WHITE);
        clear.setOnClickListener(v->{stopPlayback();project.audioClipName=null;
            project.audioClipPath=null;save();buildUI();});
        line.addView(clear,new LinearLayout.LayoutParams(dp(58),dp(49)));
        content.addView(line);
        addGap(content,8);
        addSlider("ÂM LƯỢNG CLIP",Math.round(project.audioClipVolume*100),100,
                v->{project.audioClipVolume=v/100f;save();});
        content.addView(text("Ghi âm một lớp/clip, bắt đầu từ 0:00. Nhập WAV / MP3 / M4A tối đa 30 phút.",
                11,DIM,false));
    }

    private interface SliderSave {void accept(int value);}
    private void addSlider(String title,int initial,int max,SliderSave listener) {
        LinearLayout line=row();
        TextView label=text(title,11,Color.WHITE,true);
        line.addView(label,new LinearLayout.LayoutParams(dp(145),dp(45)));
        SeekBar slider=new SeekBar(this);
        slider.setMax(max);slider.setProgress(initial);
        line.addView(slider,new LinearLayout.LayoutParams(0,dp(45),1));
        TextView number=text(String.valueOf(initial),12,ORANGE,true);
        number.setGravity(Gravity.RIGHT|Gravity.CENTER_VERTICAL);
        line.addView(number,new LinearLayout.LayoutParams(dp(39),dp(45)));
        slider.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener(){
            @Override public void onProgressChanged(SeekBar bar,int val,boolean fromUser) {
                number.setText(String.valueOf(val));if(fromUser)listener.accept(val);
            }
            @Override public void onStartTrackingTouch(SeekBar bar){}
            @Override public void onStopTrackingTouch(SeekBar bar){save();}
        });
        content.addView(line);
    }

    private void buildEffectsSection() {
        addSlider("DRIVE",project.masterDrive,100,v->{project.masterDrive=v;});
        addSlider("LOW-PASS",project.masterFilter,100,v->{project.masterFilter=v;});
        addSlider("DELAY / ECHO",project.masterDelay,50,v->{project.masterDelay=v;});
        content.addView(text("Hiệu ứng áp dụng cho cả nhạc cụ và clip khi phát/xuất.",11,DIM,false));
    }

    private void startAudioPicker(int request) {
        if(microphone.isRecording()){
            Toast.makeText(this,"Dừng ghi âm trước khi nhập file",Toast.LENGTH_SHORT).show();return;
        }
        Intent pick=new Intent(Intent.ACTION_OPEN_DOCUMENT);
        pick.addCategory(Intent.CATEGORY_OPENABLE);
        pick.setType("audio/*");
        try{startActivityForResult(pick,request);}
        catch(Exception e){Toast.makeText(this,"Không có trình chọn âm thanh",Toast.LENGTH_LONG).show();}
    }

    private void requestMicrophone() {
        if(android.os.Build.VERSION.SDK_INT>=23 &&
                checkSelfPermission(Manifest.permission.RECORD_AUDIO)!=PackageManager.PERMISSION_GRANTED){
            requestPermissions(new String[]{Manifest.permission.RECORD_AUDIO},MIC_PERMISSION);
            return;
        }
        startMicrophone();
    }

    @Override public void onRequestPermissionsResult(int request,String[] permissions,int[] results) {
        super.onRequestPermissionsResult(request,permissions,results);
        if(request==MIC_PERMISSION){
            if(results.length>0 && results[0]==PackageManager.PERMISSION_GRANTED)startMicrophone();
            else Toast.makeText(this,"Cần cấp quyền Micro để thu âm",Toast.LENGTH_LONG).show();
        }
    }

    private File makeAssetFile(String label) throws java.io.IOException {
        File dir=new File(getFilesDir(),"audio");
        if(!dir.isDirectory() && !dir.mkdirs())throw new java.io.IOException("Không tạo được thư mục audio");
        return new File(dir,label+"_"+System.nanoTime()+".wav");
    }

    private void startMicrophone() {
        stopPlayback();
        try {
            recordingFile=makeAssetFile("vocal");
            microphone.start(recordingFile,(file,error)->runOnUiThread(()->{
                if(error==null) {
                    project.audioClipPath=file.getAbsolutePath();
                    project.audioClipName="Bản thu "+new java.text.SimpleDateFormat(
                            "HH:mm dd/MM",java.util.Locale.getDefault()).format(new java.util.Date());
                    save();
                    Toast.makeText(this,"Đã lưu âm thanh thu: "+(PcmFile.frames(file.getAbsolutePath())/44100)+" giây",Toast.LENGTH_LONG).show();
                } else Toast.makeText(this,"Lỗi ghi âm: "+error,Toast.LENGTH_LONG).show();
                if(!isFinishing())buildUI();
            }));
            buildUI();
        } catch(Exception e){Toast.makeText(this,"Không thể ghi âm: "+e.getMessage(),Toast.LENGTH_LONG).show();}
    }

    private String displayFileName(Uri uri) {
        try(Cursor cur=getContentResolver().query(uri,new String[]{OpenableColumns.DISPLAY_NAME},null,null,null)) {
            if(cur!=null && cur.moveToFirst())return cur.getString(0);
        } catch(Exception ignored){}
        return "Audio imported";
    }

    private void importAudio(Uri uri,int request) {
        stopPlayback();
        final int pad=request-IMPORT_SAMPLE_REQUEST;
        final boolean clip=request==IMPORT_AUDIO_REQUEST;
        final String name=displayFileName(uri);
        Toast.makeText(this,"Đang giải mã: "+name,Toast.LENGTH_SHORT).show();
        new Thread(()->{
            try {
                File output=makeAssetFile(clip?"clip":"pad"+pad);
                AudioImporter.importToWav(getApplicationContext(),uri,output,clip?1800:30);
                runOnUiThread(()->{
                    if(clip){project.audioClipPath=output.getAbsolutePath();project.audioClipName=name;}
                    else{project.samplePaths[pad]=output.getAbsolutePath();project.sampleNames[pad]=name;}
                    save();buildUI();Toast.makeText(this,"Nhập âm thanh thành công!",Toast.LENGTH_LONG).show();
                });
            } catch(Exception e) {runOnUiThread(()->Toast.makeText(this,
                    "Không nhập được: "+e.getMessage(),Toast.LENGTH_LONG).show());}
        },"studio-audio-import").start();
    }

    private void buildProjectSection() {
        LinearLayout line = row();
        TextView saveBtn = action("💾 LƯU", PANEL, Color.WHITE);
        saveBtn.setOnClickListener(v -> { save(); Toast.makeText(this, "Đã lưu dự án", Toast.LENGTH_SHORT).show(); });
        line.addView(saveBtn, new LinearLayout.LayoutParams(0, dp(48), 1));
        addRowGap(line, 7);
        TextView reset = action("XÓA PATTERN", PANEL, Color.WHITE);
        reset.setOnClickListener(v -> new AlertDialog.Builder(this)
                .setTitle("Xóa pattern " + BANKS[project.selectedPattern] + "?")
                .setMessage("Các nốt và tiếng trống của pattern đang chọn sẽ bị xóa.")
                .setNegativeButton("Hủy", null)
                .setPositiveButton("Xóa", (dialog, which) -> {
                    player.stop();
                    project.patterns[project.selectedPattern] = new MusicProject.Pattern();
                    highlightedStep = -1;
                    save(); buildUI();
                }).show());
        line.addView(reset, new LinearLayout.LayoutParams(0, dp(48), 1.2f));
        addRowGap(line, 7);
        TextView newProject = action("BÀI MỚI", PANEL, Color.WHITE);
        newProject.setOnClickListener(v -> new AlertDialog.Builder(this)
                .setTitle("Tạo dự án trống?")
                .setMessage("Dự án hiện tại sẽ bị thay thế. Hãy xuất WAV nếu muốn giữ bản nhạc.")
                .setNegativeButton("Hủy", null)
                .setPositiveButton("Tạo mới", (dialog, which) -> {
                    stopPlayback();
                    project = MusicProject.blank();
                    highlightedStep = -1;
                    save(); buildUI();
                }).show());
        line.addView(newProject, new LinearLayout.LayoutParams(0, dp(48), 1));
        content.addView(line);
        addGap(content, 13);
        LinearLayout loopsRow = row();
        TextView loopsLabel = text("SỐ LẦN LẶP KHI XUẤT", 12, Color.WHITE, true);
        loopsRow.addView(loopsLabel, new LinearLayout.LayoutParams(0, dp(43), 1));
        TextView minus = action("−", PANEL, Color.WHITE);
        TextView count = text(project.loops + "×", 17, ORANGE, true);
        count.setGravity(Gravity.CENTER);
        TextView plus = action("+", PANEL, Color.WHITE);
        minus.setOnClickListener(v -> { project.loops = Math.max(1, project.loops - 1); count.setText(project.loops + "×"); save(); });
        plus.setOnClickListener(v -> { project.loops = Math.min(32, project.loops + 1); count.setText(project.loops + "×"); save(); });
        loopsRow.addView(minus, new LinearLayout.LayoutParams(dp(43), dp(43)));
        loopsRow.addView(count, new LinearLayout.LayoutParams(dp(50), dp(43)));
        loopsRow.addView(plus, new LinearLayout.LayoutParams(dp(43), dp(43)));
        content.addView(loopsRow);
        addGap(content, 12);
        TextView export = action("⬇ XUẤT WAV  ·  44.1 kHz", ORANGE, BG);
        export.setOnClickListener(v -> chooseExportFile(false));
        content.addView(export,new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT,dp(55)));
        addGap(content,9);
        TextView mp3=action("⬇ XUẤT MP3  ·  192 kbps",AQUA,BG);
        mp3.setOnClickListener(v->chooseExportFile(true));
        content.addView(mp3,new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT,dp(55)));
    }

    private void startPlayback() {
        stopPlayback();
        player.start(project, (step, pattern, slot) -> runOnUiThread(() -> {
            if (!player.isRunning() || isFinishing()) return;
            int before = highlightedStep;
            highlightedStep = step;
            if (before >= 0) for (int d = 0; d < 4; d++) renderCell(d, before);
            for (int d = 0; d < 4; d++) renderCell(d, step);
            if (pianoRoll != null) pianoRoll.setPlayStep(step);
            String playing = pattern < 0 ? "Nghỉ" : BANKS[pattern];
            if (currentPosition != null) currentPosition.setText("● PLAYING  /  "
                    + (slot >= 0 ? "ô " + (slot + 1) + "  /  " : "")
                    + "PAT " + playing + "  /  STEP " + (step + 1));
        }));
        if (transportButton != null) transportButton.setText("▶ ĐANG PHÁT");
    }

    private void stopPlayback() {
        player.stop();
        int before = highlightedStep;
        highlightedStep = -1;
        if (before >= 0 && drumButtons != null) {
            for (int d = 0; d < 4; d++) renderCell(d, before);
        }
        if (pianoRoll != null) pianoRoll.setPlayStep(-1);
        if (transportButton != null) transportButton.setText("▶ PHÁT");
        if (currentPosition != null) currentPosition.setText("● READY  /  44.1kHz PCM");
    }

    private void chooseExportFile(boolean mp3) {
        if(exporting){Toast.makeText(this,"Đang xuất nhạc",Toast.LENGTH_SHORT).show();return;}
        if(microphone.isRecording()){Toast.makeText(this,"Dừng thu âm trước khi xuất",Toast.LENGTH_SHORT).show();return;}
        save();
        Intent create=new Intent(Intent.ACTION_CREATE_DOCUMENT);
        create.addCategory(Intent.CATEGORY_OPENABLE);
        create.setType(mp3?"audio/mpeg":"audio/wav");
        create.putExtra(Intent.EXTRA_TITLE,"ChoongTai_Studio_"+System.currentTimeMillis()+(mp3?".mp3":".wav"));
        try{startActivityForResult(create,mp3?EXPORT_MP3_REQUEST:EXPORT_REQUEST);}
        catch(Exception e){Toast.makeText(this,"Không mở được trình chọn tệp",Toast.LENGTH_LONG).show();}
    }

    @Override protected void onActivityResult(int request,int result,Intent data) {
        super.onActivityResult(request,result,data);
        if(result!=RESULT_OK || data==null || data.getData()==null)return;
        Uri uri=data.getData();
        if((request>=IMPORT_SAMPLE_REQUEST && request<IMPORT_SAMPLE_REQUEST+4)
                || request==IMPORT_AUDIO_REQUEST){importAudio(uri,request);return;}
        if(request!=EXPORT_REQUEST && request!=EXPORT_MP3_REQUEST)return;
        final boolean mp3=request==EXPORT_MP3_REQUEST;
        exporting=true;
        final MusicProject snapshot=project.snapshot();
        Toast.makeText(this,"Đang tạo "+(mp3?"MP3":"WAV")+"...",Toast.LENGTH_SHORT).show();
        new Thread(()->{
            String resultText;
            try {
                OutputStream output=getContentResolver().openOutputStream(uri,"w");
                if(output==null)throw new java.io.IOException("Không thể mở file đầu ra");
                if(mp3)Mp3Exporter.write(output,snapshot);
                else WaveExporter.write(output,snapshot);
                resultText="Đã xuất "+(mp3?"MP3":"WAV")+" thành công!";
            } catch(Exception | LinkageError e){
                resultText="Lỗi xuất "+(mp3?"MP3":"WAV")+": "+e.getMessage();
            }
            exporting=false;
            final String message=resultText;
            runOnUiThread(()->Toast.makeText(this,message,Toast.LENGTH_LONG).show());
        },"studio-music-export").start();
    }

    @Override protected void onPause() { save(); super.onPause(); }
    @Override protected void onStop() { microphone.stop();stopPlayback();super.onStop(); }
    @Override protected void onDestroy() { player.stop(); super.onDestroy(); }
}
