package com.choongtai.musicstudio;

import android.content.Context;
import org.json.JSONArray;
import org.json.JSONObject;

public final class ProjectStore {
    private static final String STORE = "song_project";
    private ProjectStore() {}

    public static void save(Context ctx, MusicProject p) {
        try {
            JSONObject root = new JSONObject();
            root.put("version", 2);
            root.put("bpm", p.bpm);
            root.put("selectedPattern", p.selectedPattern);
            root.put("selectedMelodicTrack", p.selectedMelodicTrack);
            root.put("songMode", p.songMode);
            root.put("loops", p.loops);
            JSONArray arrangement = new JSONArray();
            JSONArray volumes = new JSONArray();
            JSONArray muted = new JSONArray();
            for (int s : p.arrangement) arrangement.put(s);
            for (float volume : p.volume) volumes.put((double) volume);
            for (boolean m : p.mute) muted.put(m);
            root.put("arrangement", arrangement);
            root.put("volume", volumes);
            root.put("mute", muted);
            JSONArray tones=new JSONArray();
            for(int tone:p.instrumentTones)tones.put(tone);
            root.put("instrumentTones",tones);
            JSONArray samplePaths = new JSONArray(), sampleNames = new JSONArray();
            for (int i=0;i<4;i++) {
                samplePaths.put(p.samplePaths[i]==null ? JSONObject.NULL : p.samplePaths[i]);
                sampleNames.put(p.sampleNames[i]==null ? JSONObject.NULL : p.sampleNames[i]);
            }
            root.put("samplePaths",samplePaths);
            root.put("sampleNames",sampleNames);
            root.put("audioClipPath",p.audioClipPath==null ? JSONObject.NULL : p.audioClipPath);
            root.put("audioClipName",p.audioClipName==null ? JSONObject.NULL : p.audioClipName);
            root.put("audioClipVolume",p.audioClipVolume);
            root.put("masterDelay",p.masterDelay);
            root.put("masterFilter",p.masterFilter);
            root.put("masterDrive",p.masterDrive);
            JSONArray banks = new JSONArray();
            for (MusicProject.Pattern pattern : p.patterns) {
                JSONObject bank = new JSONObject();
                JSONArray drums = new JSONArray();
                for (int d = 0; d < 4; d++) {
                    JSONArray steps = new JSONArray();
                    for (int s : pattern.drums[d]) steps.put(s);
                    drums.put(steps);
                }
                bank.put("drums", drums);
                JSONArray tracks = new JSONArray();
                for (int tr = 0; tr < 4; tr++) {
                    JSONArray rows = new JSONArray();
                    for (int r = 0; r < MusicProject.PITCHES; r++) {
                        JSONArray steps = new JSONArray();
                        for (int s : pattern.notes[tr][r]) steps.put(s);
                        rows.put(steps);
                    }
                    tracks.put(rows);
                }
                bank.put("notes", tracks);
                banks.put(bank);
            }
            root.put("patterns", banks);
            ctx.getSharedPreferences(STORE, Context.MODE_PRIVATE).edit()
                    .putString("project", root.toString()).apply();
        } catch (Exception ignored) {}
    }

    public static MusicProject load(Context ctx) {
        String json = ctx.getSharedPreferences(STORE, Context.MODE_PRIVATE).getString("project", null);
        if (json == null) return MusicProject.demo();
        try {
            JSONObject root = new JSONObject(json);
            MusicProject p = new MusicProject();
            p.bpm = Math.max(60, Math.min(200, root.optInt("bpm", 120)));
            p.selectedPattern = Math.max(0, Math.min(3, root.optInt("selectedPattern", 0)));
            p.selectedMelodicTrack = Math.max(0, Math.min(3, root.optInt("selectedMelodicTrack", 0)));
            p.songMode = root.optBoolean("songMode", false);
            p.loops = Math.max(1, Math.min(32, root.optInt("loops", 2)));
            JSONArray arr = root.getJSONArray("arrangement");
            for (int i = 0; i < p.arrangement.length; i++) p.arrangement[i] = Math.max(-1, Math.min(3, arr.getInt(i)));
            JSONArray vol = root.getJSONArray("volume");
            JSONArray mut = root.getJSONArray("mute");
            for (int i = 0; i < 8; i++) {
                p.volume[i] = (float) Math.max(0, Math.min(1, vol.getDouble(i)));
                p.mute[i] = mut.getBoolean(i);
            }
            JSONArray tones=root.optJSONArray("instrumentTones");
            if(tones!=null)for(int i=0;i<Math.min(4,tones.length());i++)
                p.instrumentTones[i]=Math.max(0,Math.min(3,tones.optInt(i,0)));
            JSONArray samplePaths = root.optJSONArray("samplePaths");
            JSONArray sampleNames = root.optJSONArray("sampleNames");
            if(samplePaths!=null)for(int i=0;i<Math.min(4,samplePaths.length());i++)
                if(!samplePaths.isNull(i))p.samplePaths[i]=samplePaths.optString(i);
            if(sampleNames!=null)for(int i=0;i<Math.min(4,sampleNames.length());i++)
                if(!sampleNames.isNull(i))p.sampleNames[i]=sampleNames.optString(i);
            p.audioClipPath=root.isNull("audioClipPath")?null:root.optString("audioClipPath",null);
            p.audioClipName=root.isNull("audioClipName")?null:root.optString("audioClipName",null);
            p.audioClipVolume=(float)Math.max(0,Math.min(1,root.optDouble("audioClipVolume",0.8)));
            p.masterDelay=Math.max(0,Math.min(50,root.optInt("masterDelay",0)));
            p.masterDrive=Math.max(0,Math.min(100,root.optInt("masterDrive",0)));
            p.masterFilter=Math.max(0,Math.min(100,root.optInt("masterFilter",100)));
            JSONArray banks = root.getJSONArray("patterns");
            for (int b = 0; b < 4; b++) {
                JSONObject bank = banks.getJSONObject(b);
                JSONArray drums = bank.getJSONArray("drums");
                JSONArray notes = bank.getJSONArray("notes");
                for (int d = 0; d < 4; d++) {
                    JSONArray steps = drums.getJSONArray(d);
                    for (int s = 0; s < 16; s++) p.patterns[b].drums[d][s] = Math.max(0, Math.min(2, steps.getInt(s)));
                }
                for (int tr = 0; tr < 4; tr++) {
                    JSONArray rows = notes.getJSONArray(tr);
                    for (int r = 0; r < 24; r++) {
                        JSONArray steps = rows.getJSONArray(r);
                        for (int s = 0; s < 16; s++)
                            p.patterns[b].notes[tr][r][s] = Math.max(0, Math.min(2, steps.getInt(s)));
                    }
                }
            }
            return p;
        } catch (Exception badFile) {
            return MusicProject.demo();
        }
    }
}
