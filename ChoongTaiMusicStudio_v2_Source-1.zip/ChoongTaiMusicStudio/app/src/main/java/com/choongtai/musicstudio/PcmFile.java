package com.choongtai.musicstudio;

import java.io.*;

/** Internal audio storage: canonical 44,100 Hz / mono / signed 16-bit little endian WAV. */
public final class PcmFile {
    private PcmFile() {}
    public static final int HEADER = 44;
    public static final int SAMPLE_RATE = 44100;

    public static long frames(String path) {
        if (path == null || path.isEmpty()) return 0;
        File f = new File(path);
        if (!f.isFile()) return 0;
        try (RandomAccessFile in = new RandomAccessFile(f, "r")) {
            if (!valid(in)) return 0;
            return (in.length() - HEADER) / 2;
        } catch (IOException ignored) { return 0; }
    }

    private static boolean valid(RandomAccessFile r) throws IOException {
        if (r.length() < HEADER) return false;
        r.seek(0);
        byte[] h = new byte[HEADER]; r.readFully(h);
        return h[0]=='R' && h[1]=='I' && h[2]=='F' && h[3]=='F'
                && h[8]=='W' && h[9]=='A' && h[10]=='V' && h[11]=='E'
                && h[12]=='f' && h[13]=='m' && h[14]=='t' && h[15]==' '
                && u16(h,20)==1 && u16(h,22)==1 && u32(h,24)==SAMPLE_RATE
                && u16(h,34)==16 && h[36]=='d' && h[37]=='a' && h[38]=='t' && h[39]=='a';
    }

    private static int u16(byte[] h,int i) { return (h[i]&255) | ((h[i+1]&255)<<8); }
    private static long u32(byte[] h,int i) { return (h[i]&255L)|((h[i+1]&255L)<<8)|((h[i+2]&255L)<<16)|((h[i+3]&255L)<<24); }

    public static short[] loadShortSample(String path, int maxSeconds) {
        long len = frames(path);
        if (len == 0 || len > SAMPLE_RATE * (long) maxSeconds) return null;
        try (InputStream in = new BufferedInputStream(new FileInputStream(path))) {
            long skipped = 0; while (skipped < HEADER) {
                long n = in.skip(HEADER - skipped);
                if (n <= 0) throw new EOFException(); skipped += n;
            }
            short[] result = new short[(int) len];
            byte[] chunk = new byte[8192]; int index = 0;
            while (index < result.length) {
                int count = Math.min(chunk.length, (result.length - index) * 2);
                int used = 0; while (used < count) { int n=in.read(chunk,used,count-used); if(n<0) throw new EOFException(); used+=n; }
                for(int i=0;i<count;i+=2) result[index++] = (short)((chunk[i]&255) | (chunk[i+1]<<8));
            }
            return result;
        } catch (IOException | OutOfMemoryError ignored) { return null; }
    }

    /** Random-access buffered reader, useful for long backing tracks without large allocations. */
    public static final class Reader implements AutoCloseable {
        private final RandomAccessFile file;
        private final long length;
        private final byte[] cache = new byte[8192];
        private long firstFrame = -1;
        private int cachedFrames;
        public Reader(String path) throws IOException {
            file = new RandomAccessFile(path,"r");
            if (!valid(file)) { file.close(); throw new IOException("Tệp nội bộ không đúng định dạng WAV"); }
            length = (file.length() - HEADER) / 2;
        }
        public long frames() { return length; }
        public double sampleAt(long frame) {
            if (frame < 0 || frame >= length) return 0;
            try {
                if (firstFrame < 0 || frame < firstFrame || frame >= firstFrame + cachedFrames) {
                    firstFrame = (frame / (cache.length / 2)) * (cache.length / 2);
                    int bytes = (int) Math.min(cache.length, (length - firstFrame) * 2);
                    file.seek(HEADER + firstFrame * 2);
                    file.readFully(cache,0,bytes);
                    cachedFrames = bytes / 2;
                }
                int idx = (int)(frame - firstFrame) * 2;
                return (short)((cache[idx]&255) | (cache[idx+1]<<8)) / 32768.0;
            } catch (IOException e) { return 0; }
        }
        @Override public void close() throws IOException { file.close(); }
    }

    public static final class Writer implements AutoCloseable {
        private final RandomAccessFile file;
        private long writtenFrames;
        public Writer(File output) throws IOException {
            file = new RandomAccessFile(output, "rw"); file.setLength(0);
            for (int i=0;i<HEADER;i++) file.write(0);
        }
        public void write(short[] data,int count) throws IOException {
            byte[] b=new byte[count*2];
            for(int i=0;i<count;i++) {b[i*2]=(byte)data[i]; b[i*2+1]=(byte)(data[i]>>>8);}
            write(b,0,b.length);
        }
        public void write(byte[] data,int off,int bytes) throws IOException {
            if ((bytes & 1)!=0) throw new IOException("PCM phải đủ mẫu 16-bit");
            if ((writtenFrames + bytes/2) * 2 > 0xffffffffL-36) throw new IOException("WAV lớn hơn giới hạn 4 GB");
            file.write(data,off,bytes); writtenFrames += bytes/2;
        }
        public long frames() {return writtenFrames;}
        @Override public void close() throws IOException {
            try {
                byte[] h=new byte[HEADER];
                h[0]='R';h[1]='I';h[2]='F';h[3]='F';
                put32(h,4,writtenFrames*2+36);
                h[8]='W';h[9]='A';h[10]='V';h[11]='E';
                h[12]='f';h[13]='m';h[14]='t';h[15]=' ';
                put32(h,16,16);put16(h,20,1);put16(h,22,1);put32(h,24,SAMPLE_RATE);
                put32(h,28,SAMPLE_RATE*2);put16(h,32,2);put16(h,34,16);
                h[36]='d';h[37]='a';h[38]='t';h[39]='a';put32(h,40,writtenFrames*2);
                file.seek(0);file.write(h);
            } finally {file.close();}
        }
    }
    static void put16(byte[] b,int o,long v) { b[o]=(byte)v;b[o+1]=(byte)(v>>>8); }
    static void put32(byte[] b,int o,long v) {for(int i=0;i<4;i++) b[o+i]=(byte)(v >>> (8*i));}
}
