package com.choongtai.musicstudio;

public final class MusicProject {
    public static final int STEPS = 16;
    public static final int PITCHES = 24;
    public static final int PATTERNS = 4;
    public static final int TRACKS = 8;
    public static final String[] TRACK_NAMES = {"KICK", "SNARE", "HI-HAT", "CLAP", "BASS", "PLUCK", "LEAD", "PAD"};
    public static final int[] TRACK_COLORS = {
            0xFFFF9F43, 0xFFFF647C, 0xFFFACC15, 0xFFFB7185,
            0xFF34D399, 0xFF22D3EE, 0xFF818CF8, 0xFFCB93FF
    };

    public int bpm = 120;
    public int selectedPattern = 0;
    public int selectedMelodicTrack = 0;
    public boolean songMode = false;
    public int loops = 2;
    // A blank arrangement slot is -1.
    public final int[] arrangement = {0, 1, 0, 2, 0, 1, 0, 3};
    public final float[] volume = {0.85f, 0.65f, 0.42f, 0.55f, 0.68f, 0.48f, 0.42f, 0.34f};
    public final boolean[] mute = new boolean[TRACKS];
    public static final String[] TONE_NAMES = {"ORIGINAL", "SINE", "SAW", "SQUARE"};
    public final int[] instrumentTones = new int[4];
    // App-owned canonical WAV paths; user files are copied into private storage.
    public final String[] samplePaths = new String[4];
    public final String[] sampleNames = new String[4];
    public String audioClipPath;
    public String audioClipName;
    public float audioClipVolume = 0.8f;
    public int masterDelay = 0; // 0..50% feedback, quarter-beat echo
    public int masterFilter = 100; // lowpass openness 0..100
    public int masterDrive = 0; // 0..100

    public final Pattern[] patterns = new Pattern[PATTERNS];

    public static final class Pattern {
        public final int[][] drums = new int[4][STEPS];
        public final int[][][] notes = new int[4][PITCHES][STEPS];
    }

    public MusicProject() {
        for (int i = 0; i < PATTERNS; i++) patterns[i] = new Pattern();
    }

    public static MusicProject demo() {
        MusicProject p = new MusicProject();
        for (int b = 0; b < PATTERNS; b++) {
            Pattern pat = p.patterns[b];
            for (int s = 0; s < STEPS; s++) {
                if (s % 4 == 0) pat.drums[0][s] = 2;
                if (s == 4 || s == 12) pat.drums[1][s] = 2;
                if (s % 2 == 0) pat.drums[2][s] = 1;
            }
            if (b == 1) {
                pat.drums[3][12] = 2;
                pat.drums[0][10] = 1;
                pat.notes[0][19][0] = 2;
                pat.notes[0][14][4] = 2;
                pat.notes[0][16][8] = 2;
                pat.notes[0][14][12] = 2;
            } else if (b == 2) {
                pat.drums[3][4] = 2;
                pat.drums[3][12] = 2;
                pat.notes[0][14][0] = 2;
                pat.notes[0][16][4] = 2;
                pat.notes[0][11][8] = 2;
                pat.notes[0][14][12] = 2;
            } else if (b == 3) {
                pat.drums[1][15] = 1;
                pat.notes[0][21][0] = 2;
                pat.notes[0][19][8] = 2;
                pat.notes[0][16][12] = 2;
            } else {
                pat.notes[0][23][0] = 2;
                pat.notes[0][16][4] = 2;
                pat.notes[0][19][8] = 2;
                pat.notes[0][16][12] = 2;
            }
            int[] leadSteps = {0, 2, 4, 8, 10, 12};
            int[] leadPitches = {11, 9, 7, 11, 14, 9};
            for (int i = 0; i < leadSteps.length; i++) {
                pat.notes[2][Math.min(23, leadPitches[i] + (b == 2 ? 2 : 0))][leadSteps[i]] = 1;
            }
            pat.notes[3][23][0] = 1;
            pat.notes[3][19][0] = 1;
            pat.notes[3][16][0] = 1;
        }
        return p;
    }

    /** Deep snapshot used during WAV rendering so live edits cannot corrupt an export. */
    public MusicProject snapshot() {
        MusicProject copy = new MusicProject();
        copy.bpm = bpm;
        copy.selectedPattern = selectedPattern;
        copy.selectedMelodicTrack = selectedMelodicTrack;
        copy.songMode = songMode;
        copy.loops = loops;
        copy.audioClipPath = audioClipPath;
        copy.audioClipName = audioClipName;
        copy.audioClipVolume = audioClipVolume;
        copy.masterDelay = masterDelay;
        copy.masterFilter = masterFilter;
        copy.masterDrive = masterDrive;
        System.arraycopy(samplePaths,0,copy.samplePaths,0,samplePaths.length);
        System.arraycopy(sampleNames,0,copy.sampleNames,0,sampleNames.length);
        System.arraycopy(arrangement, 0, copy.arrangement, 0, arrangement.length);
        System.arraycopy(volume, 0, copy.volume, 0, volume.length);
        System.arraycopy(mute, 0, copy.mute, 0, mute.length);
        System.arraycopy(instrumentTones,0,copy.instrumentTones,0,4);
        for (int b = 0; b < PATTERNS; b++) {
            for (int d = 0; d < 4; d++) {
                System.arraycopy(patterns[b].drums[d], 0, copy.patterns[b].drums[d], 0, STEPS);
                for (int r = 0; r < PITCHES; r++) {
                    System.arraycopy(patterns[b].notes[d][r], 0, copy.patterns[b].notes[d][r], 0, STEPS);
                }
            }
        }
        return copy;
    }

    public static MusicProject blank() { return new MusicProject(); }
}
