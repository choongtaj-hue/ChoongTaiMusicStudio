package com.choongtai.musicstudio;

import android.media.AudioFormat;
import android.media.AudioRecord;
import android.media.MediaRecorder;
import android.os.Process;
import java.io.File;

/** Microphone to private WAV file. No sample buffering of the full recording in memory. */
public final class MicRecorder {
    public interface Callback { void finished(File output, String error); }
    private volatile boolean recording;
    private Thread worker;
    private AudioRecord active;

    public synchronized boolean isRecording() { return recording; }
    public synchronized void start(File output, Callback callback) {
        if (recording) return;
        recording = true;
        worker = new Thread(() -> {
            AudioRecord recorder = null;
            String error = null;
            try {
                Process.setThreadPriority(Process.THREAD_PRIORITY_AUDIO);
                int min = AudioRecord.getMinBufferSize(44100, AudioFormat.CHANNEL_IN_MONO, AudioFormat.ENCODING_PCM_16BIT);
                if (min <= 0) throw new IllegalStateException("Thiết bị không hỗ trợ ghi âm 44.1 kHz");
                recorder = new AudioRecord(MediaRecorder.AudioSource.MIC,44100,
                        AudioFormat.CHANNEL_IN_MONO,AudioFormat.ENCODING_PCM_16BIT,Math.max(min*2,8192));
                synchronized (MicRecorder.this) { active=recorder; }
                if (recorder.getState()!=AudioRecord.STATE_INITIALIZED) throw new IllegalStateException("Không khởi tạo được micro");
                recorder.startRecording();
                byte[] buffer = new byte[4096];
                try (PcmFile.Writer writer = new PcmFile.Writer(output)) {
                    while (recording) {
                        int count = recorder.read(buffer,0,buffer.length);
                        if (count == AudioRecord.ERROR_INVALID_OPERATION || count == AudioRecord.ERROR_BAD_VALUE)
                            throw new IllegalStateException("Đọc micro thất bại: " + count);
                        if (count > 1) writer.write(buffer,0,count & ~1);
                    }
                    if (writer.frames()==0) throw new IllegalStateException("Không thu được âm thanh");
                }
            } catch (Exception | LinkageError e) { error=e.getMessage(); }
            finally {
                if (recorder != null) {
                    try { recorder.stop(); } catch (Exception ignored) {}
                    recorder.release();
                }
                synchronized (MicRecorder.this) { active=null; recording=false; worker=null; }
                if (error!=null && output.exists()) output.delete();
                callback.finished(output,error);
            }
        },"studio-microphone");
        worker.start();
    }
    public void stop() { recording = false; }
}
