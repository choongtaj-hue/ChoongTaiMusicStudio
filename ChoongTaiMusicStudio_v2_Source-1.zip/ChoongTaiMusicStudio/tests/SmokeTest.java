import com.choongtai.musicstudio.MusicProject;
import com.choongtai.musicstudio.WaveExporter;
import com.choongtai.musicstudio.PcmFile;
import com.choongtai.musicstudio.SynthEngine;
import java.io.ByteArrayOutputStream;
import java.io.File;

public final class SmokeTest {
    private static void check(boolean ok,String message){if(!ok)throw new AssertionError(message);}
    public static void main(String[] args) throws Exception {
        MusicProject p=MusicProject.demo();p.songMode=false;p.loops=1;
        MusicProject snapshot=p.snapshot();
        p.patterns[0].drums[0][0]=0;
        check(snapshot.patterns[0].drums[0][0]==2,"Snapshot not independent");
        ByteArrayOutputStream out=new ByteArrayOutputStream();
        WaveExporter.write(out,snapshot);
        byte[] audio=out.toByteArray();
        check(audio.length>10000 && audio[0]=='R' && audio[8]=='W',"Invalid RIFF/WAVE header");
        int nonzero=0;
        for(int i=44;i<audio.length;i++)if(audio[i]!=0)nonzero++;
        check(nonzero>10000,"Synth returned silence");

        File sample=File.createTempFile("studio-sample-",".wav");
        File backing=File.createTempFile("studio-backing-",".wav");
        try {
            short[] pcm=new short[9000];
            for(int i=0;i<pcm.length;i++)pcm[i]=(short)(i%3==0?16000:-12000);
            try(PcmFile.Writer writer=new PcmFile.Writer(sample)){writer.write(pcm,pcm.length);}
            try(PcmFile.Writer writer=new PcmFile.Writer(backing)){writer.write(pcm,pcm.length);}
            check(PcmFile.frames(sample.getAbsolutePath())==9000,"PCM frames incorrect");
            check(PcmFile.loadShortSample(sample.getAbsolutePath(),30)[0]==16000,"PCM sample decode incorrect");
            try(PcmFile.Reader reader=new PcmFile.Reader(backing.getAbsolutePath())) {
                check(reader.frames()==9000,"Backing reader frame count incorrect");
                check(Math.abs(reader.sampleAt(8194)-(-12000/32768.0))<.0001,"Backing reader buffering incorrect");
            }
            MusicProject p2=MusicProject.blank();
            p2.samplePaths[0]=sample.getAbsolutePath();
            p2.audioClipPath=backing.getAbsolutePath();
            p2.patterns[0].drums[0][0]=2;
            p2.masterDelay=25;p2.masterFilter=85;p2.masterDrive=10;
            short[] mixed=new short[4096];
            try(SynthEngine.Session session=new SynthEngine.Session(p2,false,16,null)){
                session.render(mixed,mixed.length);
            }
            int active=0;
            for(short s:mixed)if(s!=0)active++;
            check(active>3000,"One-shot and backing mix returned silence");
            check(SynthEngine.Session.framesFor(p2,false,1)>=9000,"Backing length not accounted for");
        } finally {sample.delete();backing.delete();}
        System.out.println("PASS: WAV, synth, snapshot, sample pad, backing clip, master FX; WAV bytes="+audio.length);
    }
}
