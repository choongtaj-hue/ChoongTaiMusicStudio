#!/bin/sh
set -eu
cd "$(dirname "$0")/.."
workdir="$(mktemp -d)"
trap 'rm -rf "$workdir"' EXIT
javac -d "$workdir" \
  app/src/main/java/com/choongtai/musicstudio/MusicProject.java \
  app/src/main/java/com/choongtai/musicstudio/PcmFile.java \
  app/src/main/java/com/choongtai/musicstudio/SynthEngine.java \
  app/src/main/java/com/choongtai/musicstudio/WaveExporter.java \
  tests/SmokeTest.java
java -cp "$workdir" SmokeTest
