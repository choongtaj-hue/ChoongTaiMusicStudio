# CHOONG TAI Music Studio 2.0 — Android Java DAW

Đây là **mã nguồn ứng dụng Android độc lập**, lấy cảm hứng từ quy trình làm beat trên điện thoại, **không phải FL Studio Mobile**, không sử dụng phần mềm hoặc tên thương hiệu FL Studio trong ứng dụng.

## Các chức năng đã lập trình

| Mục | Tính năng |
|---|---|
| Drum Machine | 4 pad Kick/Snare/Hi-hat/Clap, sequencer 16 step, 2 mức velocity |
| Piano roll | 24 nốt, 4 track Bass / Pluck / Lead / Pad; 4 âm sắc oscillator: Original / Sine / Saw / Square |
| Song arranger | 4 pattern A/B/C/D; 8 ô ghép đoạn, hỗ trợ ô trống |
| Playback | AudioTrack 44.1 kHz 16-bit mono, 60–200 BPM, chọn Pattern/Song |
| Mixer | Âm lượng và Mute 8 track synth/drums, âm lượng riêng cho clip audio |
| Sample pads | Nhập WAV 16-bit PCM, MP3, M4A khi decoder điện thoại hỗ trợ; chuyển về PCM 44.1 kHz mono, tối đa **30 giây/sample** |
| Audio clip | Nhập 1 clip audio WAV/MP3/M4A tối đa **30 phút**, bắt đầu ở 0:00, trộn trong khi phát và xuất |
| Thu micro | Ghi **1 track** giọng hát/micro thành WAV trong bộ nhớ ứng dụng, có nút Dừng; xin quyền micro khi sử dụng |
| Master FX | Drive / lowpass / echo theo BPM, được render cả trong WAV và MP3 |
| Export | WAV 44.1 kHz PCM mono; MP3 192 kbps mono qua LAME |
| Project | Lưu pattern, mixer, FX, sample path, audio clip trong dữ liệu ứng dụng; load lại lúc mở |

**Giới hạn thực tế:** Đây là bản DAW đơn giản có chức năng nâng cao, **chưa phải bản sao đầy đủ FL Studio Mobile**. Không hỗ trợ tải/chạy trực tiếp VST2/VST3 `.dll`, `.vst3`, `.so` của phần mềm desktop trên Android. Chưa có giao diện arrangement nhiều audio track với cắt/dán/di chuyển clip, thu nhiều take chồng lớp, audio monitoring chống trễ, MIDI input/export, automation lane, time-stretch chất lượng cao, soundfonts/SF2 hoặc plugin host VST3. Phần âm thanh hiện dùng **mono 44.1 kHz** (chuyển từ stereo thành mono); việc resample dùng thuật toán gọn nhẹ nên chưa đạt chất lượng phòng thu.

## Làm APK trực tiếp bằng GitHub Actions (không cần máy tính)

1. Giải nén ZIP. Trong folder `ChoongTaiMusicStudio/` có thư mục **`app`**, **`.github`**, `build.gradle` và `settings.gradle`.
2. Tạo GitHub repository trống, nhánh `main`. Upload **nội dung của `ChoongTaiMusicStudio` vào gốc repository**; đừng quên `.github/workflows/build-apk.yml`.
3. Mở tab **Actions → Build Android APK → Run workflow** (hoặc push mã nguồn sẽ tự build).
4. Sau khi chạy thành công, mở run → **Artifacts → `ChoongTai-Music-Studio-APK`** và tải ZIP artifact.
5. Giải nén ZIP artifact để lấy `app-debug.apk`; cài trên điện thoại Android 8.0 trở lên.

**Lưu ý:** GitHub Actions cần Internet để tải Android SDK/Gradle và thư viện MP3 từ JitPack. Dự án đang dùng Android Gradle Plugin `8.7.3`, Gradle `8.9`, SDK `35`, Java `17`, Android minSdk `26`, targetSdk `34`.

Hoặc mở repository bằng Android Studio → Build → Build APK(s).

## Cách sử dụng

**Sample:** ở `06 SAMPLE LIBRARY` bấm `NHẬP` trên từng pad để chọn WAV/MP3/M4A. Sample sẽ phát thay tiếng synth trên pad tương ứng. Nút `XÓA` trả lại tiếng synth mặc định. File đã import được chuyển đổi và giữ trong bộ nhớ riêng của ứng dụng.

**Thu âm:** ở `07 AUDIO / THU GIỌNG HÁT` bấm `THU MICRO`, chấp nhận quyền micro, bấm `DỪNG GHI` để lưu. Có thể dùng nút `NHẬP AUDIO` để thay bản thu bằng file có sẵn. Audio clip phát từ đầu bài (không tự căn BPM), có thanh volume riêng. **Đeo tai nghe khi thu** để tránh micro bắt lại nhạc từ loa; bản MVP ghi micro một mình, không có monitoring hay hiệu chỉnh độ trễ. Khi đưa ứng dụng xuống nền, ghi âm sẽ dừng.

**FX:** Kéo các thanh Drive / Lowpass / Echo ở mục `08 MASTER EFFECTS`, áp dụng cho cả synthesizer và audio clip.

**Xuất:** Bấm `XUẤT WAV` hoặc `XUẤT MP3` để chọn nơi lưu. WAV là PCM16 mono; MP3 mã hóa 192 kbps mono. Nếu bản thu/clip dài hơn pattern, file xuất đủ clip. Nếu mở tài liệu/file picker thì phát nhạc có thể dừng (cơ chế vòng đời Android).

## MP3 — Phụ thuộc bản quyền và khả năng tương thích

Để xuất MP3, dự án dùng `com.github.naman14:TAndroidLame:1.1` (JitPack), là wrapper của LAME dựa trên thư viện native. **TAndroidLame cấp phép GPL-3.0 (hoặc mới hơn).** Khi phát hành/sửa đổi app, cần tuân thủ giấy phép GPL của dependency và các tác phẩm liên quan: https://github.com/naman14/TAndroidLame .

Một số Android mới sử dụng **kích thước trang nhớ 16 KB**; thư viện MP3 native cũ có báo cáo chưa hỗ trợ căn chỉnh 16 KB. Trường hợp thiết bị không nạp được thư viện, nút MP3 sẽ hiện lỗi và nút WAV vẫn sử dụng được. Cần thay bằng bản LAME build NDK cập nhật/đúng ABI nếu muốn phát hành thương mại rộng rãi. Xem issue: https://github.com/naman14/TAndroidLame/issues/31 .

Import MP3/M4A dùng decoder `MediaCodec` có sẵn của thiết bị; định dạng ngoài PCM16 WAV có thể không hỗ trợ trên một số điện thoại. Mục sample nhận tối đa 30 giây, audio clip tối đa 30 phút; bản thu micro phụ thuộc bộ nhớ trống/giới hạn 4 GiB của WAV.

## Tệp dự án

```
app/src/main/java/com/choongtai/musicstudio/
  MainActivity.java      Android UI: pattern, piano, sample, mic, FX, export
  PianoRollView.java     Piano roll chỉnh nốt bằng cảm ứng
  MusicProject.java      Pattern, sample path, audio clip, master FX
  ProjectStore.java      JSON persistence
  AudioRunner.java       AudioTrack playback
  SynthEngine.java       Synth + sample one-shots + streaming audio backing + FX
  PcmFile.java           WAV16 mono 44.1k reader/writer, sample loader
  AudioImporter.java     Android MediaCodec / WAV PCM16 import
  MicRecorder.java       AudioRecord mic → WAV
  WaveExporter.java      Synth → WAV offline
  Mp3Exporter.java       Synth → LAME MP3 offline
.github/workflows/build-apk.yml
```

## Kiểm tra và trạng thái build

Có `tests/test-core.sh` dùng `javac` độc lập để kiểm tra synth, WAV, snapshot, tải sample, đọc backing clip và FX: `bash tests/test-core.sh`.

**CHƯA xác nhận build APK thật** trong môi trường tạo dự án này do không có Android SDK, Gradle hay Android emulator. Chưa có kiểm thử mic, MediaCodec và MP3 trên thiết bị Android thật. Build Actions là quy trình được cấu hình, chưa phải bằng chứng rằng APK đã build thành công.

## Quyền riêng tư

Ứng dụng offline không có dịch vụ backend; file nhập và bản thu được lưu vào vùng private app. `RECORD_AUDIO` chỉ được hỏi khi bấm ghi âm. File xuất đi qua Android Storage Access Framework. Khi xóa dữ liệu ứng dụng/gỡ cài đặt, nội dung project và bản thu private có thể bị mất; hãy xuất file nhạc trước khi gỡ.
